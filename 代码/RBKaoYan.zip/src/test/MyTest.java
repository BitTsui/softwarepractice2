package test;


import dao.StudentDao;
import dao.impl.StudentDaoImpl;

/**
 * Types
 * @author dandelion
 * @time 2019年3月18日下午1:22:43
 * @类名 MyTest
 * @作用 测试代码专用类
 */
public class MyTest {

	public static void main(String[] args) {
		StudentDao sd = new StudentDaoImpl();
		sd.getStudentByYearPage("2019", 1, 15);
		
	}
}
