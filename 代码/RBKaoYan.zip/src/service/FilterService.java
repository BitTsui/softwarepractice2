package service;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.ManagerDao;
import dao.impl.ManagerDaoImpl;
/**
 * Types
 * @author dandelion
 * @time 2019年3月16日下午8:18:29
 * @类名 FilterService
 * @作用 登录检查过滤器，
 * 		所有需要管理员权限的页面，访问时都要过一下这个过滤器
 * 		管理员已登录，正常访问
 * 		管理员未登录，跳转到登录页面
 * @调用 
 * @返回值类型 
 */
public class FilterService implements Filter {
    public FilterService() {
    }
    //服务器销毁时运行
   	public void destroy() {
   		System.out.println("过滤器销毁了【service/FilterService.java】...");
   	}
   	//范围内的HTML或jsp运行时运行【jsp运行一次，这个运行一次】
   	public void doFilter(ServletRequest srequest, 
   			ServletResponse sresponse, FilterChain chain) 
   			throws IOException, ServletException {
   		HttpServletRequest request = (HttpServletRequest)srequest;
   		HttpServletResponse response = (HttpServletResponse)sresponse;
   		//chain的作用是给下一个过滤器放行
   		chain.doFilter(srequest, sresponse);
   		System.out.println("我是过滤器【service/FilterService.java】...");
   		//设置编码、防治乱码
   		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		//用URL接收需要进行cookieCheck登录验证的jsp的url
		//URL表示最终会跳转的页面，也可能是loginPage.jsp
		//-------------cookie与数据库比对的开始--------------------
		Cookie[] cs = request.getCookies();
		ManagerDao md = new ManagerDaoImpl();
		//checkRes接收登录验证的结果，并返回给原网页
		String checkRes = "登录测试";
		boolean havaLogin = false;
		if(cs!=null){
			/* 如果找到管理员的cookie，且账号密码正确，则跳转到管理员页面 */
	        for(Cookie c:cs){
	            String id = c.getName();
	            String pwd = c.getValue();
	            //checkRes可能接收的值："无此账号"、"密码错误"、"登录成功"
	            checkRes = md.login(id, pwd);
	            /* 
	             * 如果管理员已登录:
	             *    1.havaLogin标记为已登录true，
	             *    2.重定向传参【登录验证的结果checkRes】
	             */
	    		if(checkRes.equals("登录成功")){
	    			havaLogin = true;
	    			break;
	    		}
	        }
			/* 如果管理员未登录，跳转到登录页面 */
	        if(!havaLogin){
   		        response.sendRedirect("../JSP/mainPage.jsp");
	        }
		}
   	}
   	//服务器开启时运行
   	public void init(FilterConfig fConfig) 
   			throws ServletException {
   		System.out.println("过滤器创建了【service/FilterService.java】...");
   	}

}
