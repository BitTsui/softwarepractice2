package service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Score;
import dao.ManagerDao;
import dao.impl.ManagerDaoImpl;
/**
 * Types
 * @author dandelion
 * @time 2019年3月17日下午9:42:15
 * @类名 AddScoreService
 * @作用 从管理员添加页面接收学生的成绩信息个数据，
 * 		调用DAO，添加学生成绩信息数据到score表。
 * @调用 
 * @返回值类型 
 */
@WebServlet("/addScoreService")
public class AddScoreService extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) 
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		//-----------------添加学生成绩信息（3）--------------------
		long id = Long.parseLong(request.getParameter("id"));
		String name = request.getParameter("name");
		String politics_score = request.getParameter("politics_score");
		//默认为0
		if(politics_score.equals("")){
			politics_score="0";
		}
		String english_subject = request.getParameter("english_subject");
		String english_score = request.getParameter("english_score");
		//默认为0
		if(english_score.equals("")){
			english_score="0";
		}
		String math_subject = request.getParameter("math_subject");
		String math_score = request.getParameter("math_score");
		//默认为0
		if(math_score.equals("")){
			math_score="0";
		}
		String major_subject = request.getParameter("major_subject");
		String major_score = request.getParameter("major_score");
		//默认为0
		if(major_score.equals("")){
			major_score="0";
		}
		String score_year = request.getParameter("score_year");
		//默认为0
		if(score_year.equals("")){
			score_year="0";
		}
		//实例化学生成绩信息类score
		Score score = new Score();
		score.setId(id);
		score.setName(name);
		score.setPolitics_score(politics_score);
		score.setEnglish_subject(english_subject);
		score.setEnglish_score(english_score);
		score.setMath_subject(math_subject);
		score.setMath_score(math_score);
		score.setMajor_subject(major_subject);
		score.setMajor_score(major_score);
		score.setScore_year(score_year);
		score.print();
		//将学生的成绩信息类中的数据，添加到score表
		ManagerDao md = new ManagerDaoImpl();
		boolean flagScore = md.addScore(score);
		if(flagScore){
			response.getWriter().println(
				  "<script type='text/javascript'>"
				+ "		alert('成功添加学生成绩数据');"
				+ "		window.location.href='JSP/mainPage.jsp';"
				+ "</script>");
		}else{
			response.getWriter().println(
				  "<script type='text/javascript'>"
				+ "		alert('添加学生成绩数据似乎出了一些问题');"
				+ "		window.location.href='JSP/mainPage.jsp';"
				+ "</script>");
		}
	}
}
