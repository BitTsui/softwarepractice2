package service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Info;
import dao.ManagerDao;
import dao.impl.ManagerDaoImpl;
/**
 * Types
 * @author dandelion
 * @time 2019年3月17日下午2:48:42
 * @类名 ModifyInfoService
 * @作用 从管理员修改页面接收学生的详细信息数据，
 * 		调用DAO，修改学生的info表的数据
 * @调用 
 * @返回值类型 
 */
@WebServlet("/modifyInfoService")
public class ModifyInfoService extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) 
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		//-----------------修改学生详细信息（2）--------------------
		long id = Long.parseLong(request.getParameter("id"));
		String name = request.getParameter("name");
		String sex = request.getParameter("sex");
		String tel = request.getParameter("tel");
		String qq = request.getParameter("qq");
		String wechat = request.getParameter("wechat");
		String blog = request.getParameter("blog");
		String github = request.getParameter("github");
		//实例化学生详细信息类info
		Info info = new Info();
		info.setId(id);
		info.setName(name);
		info.setSex(sex);
		info.setTel(tel);
		info.setQq(qq);
		info.setWechat(wechat);
		info.setBlog(blog);
		info.setGithub(github);
		info.print();
		//修改数据库中对应的学生的详细信息类中的数据
		ManagerDao md = new ManagerDaoImpl();
		boolean flagInfo = md.modifyInfo(info);
		if(flagInfo){
			response.getWriter().println(
				  "<script type='text/javascript'>"
				+ "		alert('成功修改学生详细数据');"
				+ "		window.location.href='JSP/mainPage.jsp';"
				+ "</script>");
		}else{
			response.getWriter().println(
				  "<script type='text/javascript'>"
				+ "		alert('修改学生详细数据似乎出了一些问题');"
				+ "		window.location.href='JSP/mainPage.jsp';"
				+ "</script>");
			response.sendRedirect("addInfoPage.jsp?id="+id);
		}
	}

}
