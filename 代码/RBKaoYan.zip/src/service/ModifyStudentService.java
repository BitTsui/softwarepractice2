package service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Student;
import dao.ManagerDao;
import dao.impl.ManagerDaoImpl;

/**
 * Types
 * @author dandelion
 * @time 2019年3月15日上午9:54:39
 * @类名 ModifyStudentService
 * @作用 从管理员修改页面接收学生的三个数据，
 * 		调用DAO，修改学生的三个数据库中的数据
 * @调用 
 * @返回值类型 
 */
@WebServlet("/modifyStudentService")
public class ModifyStudentService extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) 
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		//-----------------修改学生基本信息（1）--------------------
		long id = Long.parseLong(request.getParameter("id"));
		String name = request.getParameter("name");
		String sch = request.getParameter("sch");
		String college = request.getParameter("college");
		String major = request.getParameter("major");
		String clazz = request.getParameter("clazz");
		String register_sch = request.getParameter("register_sch");
		String register_major = request.getParameter("register_major");
		String register_num = request.getParameter("register_num");
		String score_total_str = request.getParameter("score_total");
		//score_total总分的默认值是0
		int score_total = 0;
		if(!score_total_str.equals("")){
			score_total = Integer.parseInt(score_total_str);
		}
		System.out.println("score_total:"+score_total);
		String score_year = request.getParameter("score_year");
		//实例化学生基本信息类student
		Student student = new Student();
		student.setId(id);
		student.setName(name);
		student.setSch(sch);
		student.setCollege(college);
		student.setMajor(major);
		student.setClazz(clazz);
		student.setRegister_sch(register_sch);
		student.setRegister_major(register_major);
		student.setRegister_num(register_num);
		student.setScore_total(score_total);
		student.setScore_year(score_year);
		student.print();
		
		//修改数据库中对应的学生基本信息类中的数据
		ManagerDao md = new ManagerDaoImpl();
		boolean flagStu = md.modifyStudent(student);
		boolean flagName = md.updateNamebyId(id, name);
		if(flagStu&&flagName){
			response.getWriter().println(
				  "<script type='text/javascript'>"
				+ "		alert('成功修改学生基本数据（包括姓名同步）');"
				+ "		window.location.href='JSP/mainPage.jsp';"
				+ "</script>");
		}else if(flagStu){
			response.getWriter().println(
				  "<script type='text/javascript'>"
				+ "		alert('成功修改学生基本数据');"
				+ "		window.location.href='JSP/mainPage.jsp';"
				+ "</script>");
		}else{
			response.getWriter().println(
				  "<script type='text/javascript'>"
				+ "		alert('修改学生基本数据似乎出了一些问题');"
				+ "		window.location.href='JSP/mainPage.jsp';"
				+ "</script>");
		}
	}
}
