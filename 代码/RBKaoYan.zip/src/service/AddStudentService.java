package service;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Student;
import dao.ManagerDao;
import dao.StudentDao;
import dao.impl.ManagerDaoImpl;
import dao.impl.StudentDaoImpl;

/**
 * Types
 * @author dandelion
 * @time 2019年3月13日下午8:56:30
 * @类名 AddStudentService
 * @作用 从管理员添加页面接收学生的三个数据，
 * 		调用DAO，添加学生数据到三个数据库。
 * @调用 
 */
@WebServlet("/addStudentService")
public class AddStudentService extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) 
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		StudentDao sd = new StudentDaoImpl();
		//-----------------添加学生基本信息（1）--------------------
		long id = Long.parseLong(request.getParameter("id"));
		//如果插入的学号已存在，提示学号重复并返回addStudentPage.jsp
		try {
			if(sd.getStudentById(String.valueOf(id)).next()){
				response.getWriter().println(
					  "<script type='text/javascript'>"
					+ "		alert('学号已存在');"
					+ "		window.location.href='JSP/addStudentPage.jsp';"
					+ "</script>");
			}else{
				String name = request.getParameter("name");
				String sch = request.getParameter("sch");
				String college = request.getParameter("college");
				String major = request.getParameter("major");
				String clazz = request.getParameter("clazz");
				String register_sch = request.getParameter("register_sch");
				String register_major = request.getParameter("register_major");
				String register_num = request.getParameter("register_num");
				String score_total_str = request.getParameter("score_total");
				//score_total总分的默认值是0
				int score_total = 0;
				if(!score_total_str.equals("")){
					score_total = Integer.parseInt(score_total_str);
				}
				System.out.println("score_total:"+score_total);
				String score_year = request.getParameter("score_year");
				//实例化学生基本信息类student
				Student student = new Student();
				student.setId(id);
				student.setName(name);
				student.setSch(sch);
				student.setCollege(college);
				student.setMajor(major);
				student.setClazz(clazz);
				student.setRegister_sch(register_sch);
				student.setRegister_major(register_major);
				student.setRegister_num(register_num);
				student.setScore_total(score_total);
				student.setScore_year(score_year);
				student.print();
				//将学生的基本信息数据，添加到student表
				ManagerDao md = new ManagerDaoImpl();
				boolean flagStu = md.addStudent(student);
				if(flagStu){
					response.getWriter().println(
						  "<script type='text/javascript'>"
						+ "		alert('成功添加学生基本数据');"
						+ "		window.location.href='JSP/mainPage.jsp';"
						+ "</script>");
				}else{
					response.getWriter().println(
						  "<script type='text/javascript'>"
						+ "		alert('添加学生基本数据似乎出了一些问题');"
						+ "		window.location.href='JSP/mainPage.jsp';"
						+ "</script>");
				}
			}
		} catch (SQLException e) {
			System.out.println("【service/AddStudentService.java出现了错误】");
			e.printStackTrace();
		}
	}
}
