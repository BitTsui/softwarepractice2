package service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Info;
import dao.ManagerDao;
import dao.impl.ManagerDaoImpl;

/**
 * Types
 * @author dandelion
 * @time 2019年3月17日下午7:46:37
 * @类名 AddInfoService
 * @作用 从管理员添加页面接收学生的详细信息个数据，
 * 		调用DAO，添加学生详细信息数据到info表。
 * @调用 
 * @返回值类型 
 */
@WebServlet("/addInfoService")
public class AddInfoService extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) 
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		//-----------------添加学生详细信息（2）--------------------
		long id = Long.parseLong(request.getParameter("id"));
		String name = request.getParameter("name");
		String sex = request.getParameter("sex"); 
		String tel = request.getParameter("tel");
		String qq = request.getParameter("qq");
		String wechat = request.getParameter("wechat");
		String blog = request.getParameter("blog");
		String github = request.getParameter("github");
		//实例化学生详细信息类info
		Info info = new Info();
		info.setId(id);
		info.setName(name);
		info.setSex(sex);
		info.setTel(tel);
		info.setQq(qq);
		info.setWechat(wechat);
		info.setBlog(blog);
		info.setGithub(github);
		info.print();
		//将学生的详细信息类中的数据，添加到info表
		ManagerDao md = new ManagerDaoImpl();
		boolean flagInfo = md.addInfo(info);
		if(flagInfo){
			response.getWriter().println(
				  "<script type='text/javascript'>"
				+ "		alert('成功添加学生详细数据');"
				+ "		window.location.href='JSP/mainPage.jsp';"
				+ "</script>");
		}else{
			response.getWriter().println(
				  "<script type='text/javascript'>"
				+ "		alert('添加学生详细数据似乎出了一些问题');"
				+ "		window.location.href='JSP/mainPage.jsp';"
				+ "</script>");
		}
	}

}
