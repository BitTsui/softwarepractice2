package bean;

/**
 * Types
 * @author dandelion
 * @time 2019年3月2日下午2:37:08
 * @作用 学生Student类
 */
public class Student {
	private long id;
	private String name;
	private String sch;
	private String college;
	private String major;
	private String clazz;
	private String register_sch;
	private String register_major;
	private String register_num;
	private int score_total;
	private String score_year;
	public Student(){
		sch = "无";
		college = "无";
		major = "无";
		clazz = "无";
		register_sch = "无";
		register_major = "无";
		register_num = "无";
		score_total = 0;
		score_year = "无";
	}
	public Student(long id, String name, String sch, String college, String major, String clazz, String register_sch,
			String register_major, String register_num, int score_total, String score_year) {
		super();
		this.id = id;
		this.name = name;
		this.sch = sch;
		this.college = college;
		this.major = major;
		this.clazz = clazz;
		this.register_sch = register_sch;
		this.register_major = register_major;
		this.register_num = register_num;
		this.score_total = score_total;
		this.score_year = score_year;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSch() {
		return sch;
	}
	public void setSch(String sch) {
		this.sch = sch;
	}
	public String getCollege() {
		return college;
	}
	public void setCollege(String college) {
		this.college = college;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public String getClazz() {
		return clazz;
	}
	public void setClazz(String clazz) {
		this.clazz = clazz;
	}
	public String getRegister_sch() {
		return register_sch;
	}
	public void setRegister_sch(String register_sch) {
		this.register_sch = register_sch;
	}
	public String getRegister_major() {
		return register_major;
	}
	public void setRegister_major(String register_major) {
		this.register_major = register_major;
	}
	public String getRegister_num() {
		return register_num;
	}
	public void setRegister_num(String register_num) {
		this.register_num = register_num;
	}
	public int getScore_total() {
		return score_total;
	}
	public void setScore_total(int score_total) {
		this.score_total = score_total;
	}
	public String getScore_year() {
		return score_year;
	}
	public void setScore_year(String score_year) {
		this.score_year = score_year;
	}
	//输出数据
	public void print(){
		System.out.println("学号："+id);
		System.out.println("姓名："+name);
		System.out.println("学校："+sch);
		System.out.println("学院："+college);
		System.out.println("专业："+major);
		System.out.println("班级："+clazz);
		System.out.println("报考院校："+register_sch);
		System.out.println("报考专业："+register_major);
		System.out.println("准考证号："+register_num);
		System.out.println("总分："+score_total);
		System.out.println("考研年份："+score_year);
//		id,name, sch, college,major,clazz,register_sch,
//		register_major,register_num,score_total
	}
}
