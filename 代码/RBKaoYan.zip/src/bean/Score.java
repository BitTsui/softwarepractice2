package bean;
/**
 * @author dandelion
 * @time 2019年3月12日下午9:37:41
 * @方法名 
 * @作用 
 * @调用 
 * @返回值类型 
 */
public class Score {
	private long id;
	private String name;
	private String politics_score;
	private String english_subject;
	private String english_score;
	private String math_subject;
	private String math_score;
	private String major_subject;
	private String major_score;
	private String score_year;
	public Score(){
		politics_score = "无";
		english_subject = "无";
		english_score = "无";
		math_subject = "无";
		math_score = "无";
		major_subject = "无";
		major_score = "无";
		score_year = "无";
	}
	public Score(long id, String name, String politics_score, String english_subject, String english_score,
			String math_subject, String math_score, String major_subject, String major_score, String score_year) {
		super();
		this.id = id;
		this.name = name;
		this.politics_score = politics_score;
		this.english_subject = english_subject;
		this.english_score = english_score;
		this.math_subject = math_subject;
		this.math_score = math_score;
		this.major_subject = major_subject;
		this.major_score = major_score;
		this.score_year = score_year;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPolitics_score() {
		return politics_score;
	}
	public void setPolitics_score(String politics_score) {
		this.politics_score = politics_score;
	}
	public String getEnglish_subject() {
		return english_subject;
	}
	public void setEnglish_subject(String english_subject) {
		this.english_subject = english_subject;
	}
	public String getEnglish_score() {
		return english_score;
	}
	public void setEnglish_score(String english_score) {
		this.english_score = english_score;
	}
	public String getMath_subject() {
		return math_subject;
	}
	public void setMath_subject(String math_subject) {
		this.math_subject = math_subject;
	}
	public String getMath_score() {
		return math_score;
	}
	public void setMath_score(String math_score) {
		this.math_score = math_score;
	}
	public String getMajor_subject() {
		return major_subject;
	}
	public void setMajor_subject(String major_subject) {
		this.major_subject = major_subject;
	}
	public String getMajor_score() {
		return major_score;
	}
	public void setMajor_score(String major_score) {
		this.major_score = major_score;
	}
	public String getScore_year() {
		return score_year;
	}
	public void setScore_year(String score_year) {
		this.score_year = score_year;
	}
	public void print(){
		System.out.println("学号："+id);
		System.out.println("姓名："+name);
		System.out.println("政治单科分："+politics_score);
		System.out.println("英语备注："+english_subject);
		System.out.println("英语单科分："+english_score);
		System.out.println("数学备注："+math_subject);
		System.out.println("数学单科分："+math_score);
		System.out.println("专业课备注："+major_subject);
		System.out.println("专业课成绩："+major_score);
		System.out.println("考研年份："+score_year);
	}
//	id,name,politics_score,english_subject,english_score,
//	math_subject,math_score,major_subject,major_score
}

