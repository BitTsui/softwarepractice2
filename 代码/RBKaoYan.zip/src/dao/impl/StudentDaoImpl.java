package dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.PreparedStatement;

import bean.Student;
import dao.StudentDao;
import db.DBConn;
/**
 * Types
 * @author dandelion
 * @time 2019年3月12日下午9:27:38
 * @方法名 StudentDao
 * @作用 不需要管理员权限就可以进行的操作
 * 		1.mainPage的数据获取，以及学生详细数据、成绩数据的获取
 * @调用 
 * @返回值类型 
 */
public class StudentDaoImpl implements StudentDao{
	/**
	 * Methods
	 * @author dandelion
	 * @time 2019年3月2日下午2:09:52
	 * @方法名 getAllStudent
	 * @作用 根据考研年份返回数据表student的所有内容
	 * @调用 mainPage.jsp
	 * @返回值类型 ResultSet
	 *     rs.getString(1)---学号
	 *     rs.getString(2)---姓名
	 *     rs.getString(3)---学校
	 *     rs.getString(4)---学院
	 *     rs.getString(5)---专业
	 *     rs.getString(6)---班级
	 *     rs.getString(7)---报考院校
	 *     rs.getString(8)---报考专业
	 *     rs.getString(9)---准考证号
	 *     rs.getString(10)---总分
	 *     rs.getSting(11)---考研年份
	 */
	public ResultSet getAllStudent(){
		Connection conn = null;		
		Statement stat =null;
		ResultSet rs=null;
		try{
			conn=DBConn.getConnection();
			String sql="select * from student order by score_total desc";
			stat=conn.createStatement();//执行SQL语句
			rs = stat.executeQuery(sql);
			return rs;
		}catch(Exception e){
			System.out.println("查询数据时发生异常【StudentDao.java\\getAllStudent】");
			e.printStackTrace();
			return null;
		}finally{
			//注意，此处不能close,否则返回值无法传递
		}
	}
	/**
	 * Methods
	 * @author dandelion
	 * @time 2019年3月4日下午9:44:15
	 * @方法名 getStudentById
	 * @作用 根据学号返回数据表student内容
	 * @调用 infoPage.jsp
	 * @返回值类型 ResultSet
	 * 	   rs.getString(1)---学号
	 *     rs.getString(2)---姓名
	 *     rs.getString(3)---学校
	 *     rs.getString(4)---学院
	 *     rs.getString(5)---专业
	 *     rs.getString(6)---班级
	 *     rs.getString(7)---报考院校
	 *     rs.getString(8)---报考专业
	 *     rs.getString(9)---准考证号
	 *     rs.getInt(10)---总分
	 *     rs.getSting(11)---考研年份
	 */
	public ResultSet getStudentById(String id){
		Connection conn = null;		
		PreparedStatement ps =null;
		ResultSet rs=null;
		try{
			conn=DBConn.getConnection();
			String sql="select * from student where id=?";
			ps=(PreparedStatement) conn.prepareStatement(sql);//执行SQL语句
			ps.setString(1, id);
			rs = ps.executeQuery();
			return rs;
		}catch(Exception e){
			System.out.println("查询数据时发生异常【StudentDao.java\\getStudentById】");
			e.printStackTrace();
			return null;
		}finally{
			//注意，此处不能close,否则返回值无法传递
		}
	}
	/**
	 * Methods
	 * @author dandelion
	 * @time 2019年3月4日下午1:05:05
	 * @方法名 getInfoById
	 * @作用 根据学号返回数据表info内容
	 * @调用 infoPage.jsp
	 * @返回值类型 ResultSet
	 *     rs.getString(1)---学号
	 *     rs.getString(2)---姓名
	 *     rs.getString(3)---性别
	 *     rs.getString(4)---电话
	 *     rs.getString(5)---QQ
	 *     rs.getString(6)---微信
	 *     rs.getString(7)---博客
	 *     rs.getString(8)---GitHub
	 */
	public ResultSet getInfoById(String id){
		Connection conn = null;		
		PreparedStatement ps =null;
		ResultSet rs=null;
		try{
			conn=DBConn.getConnection();
			String sql="select * from info where id=?";
			ps=(PreparedStatement) conn.prepareStatement(sql);//执行SQL语句
			ps.setString(1, id);
			rs = ps.executeQuery();
			return rs;
		}catch(Exception e){
			System.out.println("查询数据时发生异常【StudentDao.java\\getInfoById】");
			e.printStackTrace();
			return null;
		}finally{
			//注意，此处不能close,否则返回值无法传递
		}
	}
	/**
	 * Methods
	 * @author dandelion
	 * @time 2019年3月4日下午8:48:44
	 * @方法名 getScoreById
	 * @作用 根据学号返回数据表score内容
	 * @调用 scorePage.jsp
	 * @返回值类型 ResultSet
	 *     rs.getString(1)---学号
	 *     rs.getString(2)---姓名
	 *     rs.getString(3)---政治成绩
	 *     rs.getString(4)---英语备注
	 *     rs.getString(5)---英语成绩
	 *     rs.getString(6)---数学备注
	 *     rs.getString(7)---数学成绩
	 *     rs.getString(8)---专业课备注
	 *     rs.getString(9)---专业课成绩	
	 *     rs.getString(10)---参加考研年份	
	 */
	public ResultSet getScoreById(String id){
		Connection conn = null;		
		PreparedStatement ps =null;
		ResultSet rs=null;
		try{
			conn=DBConn.getConnection();
			String sql="select * from score where id=?";
			ps=(PreparedStatement) conn.prepareStatement(sql);//执行SQL语句
			ps.setString(1, id);
			rs = ps.executeQuery();
			return rs;
		}catch(Exception e){
			System.out.println("查询数据时发生异常【StudentDao.java\\getScoreById】");
			e.printStackTrace();
			return null;
		}finally{
			//注意，此处不能close,否则返回值无法传递
		}
	}
	@Override
	public ResultSet getStudentByYear(String score_year) {
		Connection conn = null;		
		PreparedStatement ps =null;
		ResultSet rs=null;
		try{
			conn=DBConn.getConnection();
			String sql="select * from student where score_year=?  order by score_total desc";
			ps=(PreparedStatement) conn.prepareStatement(sql);//执行SQL语句
			ps.setString(1, score_year);
			rs = ps.executeQuery();
			return rs;
		}catch(Exception e){
			System.out.println("查询数据时发生异常【StudentDao.java\\getStudentByYear】");
			e.printStackTrace();
			return null;
		}finally{
			//注意，此处不能close,否则返回值无法传递
		}
	}
	@Override
	public int getStudentCountByYear(String score_year){
		int length = 0;
		ResultSet rs = getStudentByYear(score_year);
		try {
			//移动到最后
			rs.last();
			//getRow:得到光标当前所指定的行号
			//获取结果集长度
			length = rs.getRow();
		} catch (SQLException e) {
			System.out.println("查询数据时发生异常【StudentDao.java\\getStudentLengthByYear】");
			e.printStackTrace();
		}
		return length;
	}
	@Override
	public List<Student> getStudentByYearPage(String score_year, int pageNow, int pageSize) {
		ResultSet rs = getStudentByYear(score_year);
		//定义listStudent为要返回的List，内容是第pageNow页的学生报考基本数据
		List<Student> listStudent = new ArrayList<Student>();
		Student student = new Student();
		//i记录的是第i条数据
		//第pageNow页
		int i=0;
		try {
			while(rs.next()){
				if(i/pageSize+1!=pageNow){
					i++;
					continue;
				}
				student.setId(Long.parseLong(rs.getString(1)));
				student.setName(rs.getString(2));
				student.setClazz(rs.getString(6));
				student.setRegister_sch(rs.getString(7));
				student.setRegister_major(rs.getString(8));
				student.setRegister_num(rs.getString(9));
				student.setScore_total(Integer.parseInt(rs.getString(10)));
				listStudent.add(student);
				student = new Student();
				i++;
			}
		} catch (SQLException e){
			e.printStackTrace();
		}
		return listStudent;
	}
	@Override
	public int getPageCountByYear(String score_year, int pageSize) {
		int pageCount =0;
		int studentCount = getStudentCountByYear(score_year);
		pageCount = studentCount/pageSize;
		if(studentCount%pageSize>0){
			pageCount++;
		}
		return pageCount;
	}
}