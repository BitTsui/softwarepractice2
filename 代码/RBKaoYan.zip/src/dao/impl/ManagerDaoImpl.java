package dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;

import com.mysql.jdbc.PreparedStatement;

import bean.Info;
import bean.Score;
import bean.Student;
import dao.ManagerDao;
import db.DBConn;

/**
 * Types
 * @author dandelion
 * @time 2019年3月5日下午2:47:12
 * @作用 实现管理员登录、添加学生、修改学生等功能
 * @调用 
 * @返回值类型
 */
public class ManagerDaoImpl implements ManagerDao{
	/**
	 * Methods
	 * @author dandelion
	 * @time 2019年3月5日下午2:48:28
	 * @方法名 login
	 * @作用 实现管理员登录功能
	 * @调用 
	 * @返回值类型 String
	 */
	@SuppressWarnings("finally")
	public String login(String id,String pwd){
		Connection conn = null;
		PreparedStatement ps =null;
		ResultSet rs=null;
		boolean flagCheckId=false;
		boolean flagCheckPwd=false;
		String str="";
		try{
			conn=DBConn.getConnection();
			String sql="select pwd from manager where id=?";
			ps=(PreparedStatement) conn.prepareStatement(sql);//执行SQL语句
			ps.setString(1, id);
			rs = ps.executeQuery();
			if(rs.next()){
				flagCheckId=true;
				flagCheckPwd=rs.getString(1).equals(pwd);
			}
		}catch(Exception e){
			System.out.println("查询数据时发生异常【ManagerDaoImpl.java\\login】");
			e.printStackTrace();
		}finally{
			if(flagCheckId == false){
				str = "无此账号";
			}else if(flagCheckPwd == false){
				str = "密码错误";
			}else{
				str="登录成功";
			}
			return str;
			//注意，此处不能close,否则返回值无法传递
		}
	}
	/**
	 * Methods
	 * @author dandelion
	 * @time 2019年3月7日下午9:06:36
	 * @方法名 getManagerById
	 * @作用 根据编号返回数据表manager内容
	 * @调用 
	 * @返回值类型 ResultSet
	 */
	public ResultSet getManagerById(String id){
		Connection conn = null;		
		PreparedStatement ps =null;
		ResultSet rs=null;
		try{
			conn=DBConn.getConnection();
			String sql="select * from manager where id=?";
			ps=(PreparedStatement) conn.prepareStatement(sql);//执行SQL语句
			ps.setString(1, id);
			rs = ps.executeQuery();
			return rs;
		}catch(Exception e){
			System.out.println("查询数据时发生异常【ManagerDaoImpl.java\\getManagerById】");
			e.printStackTrace();
			return null;
		}finally{
			//注意，此处不能close,否则返回值无法传递
		}
	}
	/**
	 * Methods
	 * @author dandelion
	 * @time 2019年3月12日下午4:56:49
	 * @方法名 addStudent
	 * @作用 添加学生基本信息
	 * @调用 AddStudentService.java
	 * @返回值类型 boolean，true表示插入成功，false表示插入失败
	 */
	public boolean addStudent(Student student){
		Connection conn = null;										//声明Connection对象
		PreparedStatement perstat =null;								//声明PreparedStatement对象
		int rows=0;
		try{
			conn=DBConn.getConnection();
			String sql="insert into student(id,name,sch,college,major,class,register_sch,register_major,register_num,score_total,score_year) values(?,?,?,?,?,?,?,?,?,?,?)";
			perstat=(PreparedStatement) conn.prepareStatement(sql);//执行SQL语句
			perstat.setLong(1,student.getId());
			perstat.setString(2,student.getName());
			perstat.setString(3,student.getSch());
			perstat.setString(4,student.getCollege());
			perstat.setString(5,student.getMajor());
			perstat.setString(6,student.getClazz());
			perstat.setString(7,student.getRegister_sch());
			perstat.setString(8,student.getRegister_major());
			perstat.setString(9,student.getRegister_num());
			perstat.setInt(10,student.getScore_total());
			perstat.setString(11,student.getScore_year());
			rows=perstat.executeUpdate();//rows接收更新结果,rows大于0表示插入成功
		}catch(Exception e){
			System.out.println("【ManagerDaoImpl.java\\addStudent】插入基本信息数据时发生异常");
			e.printStackTrace();
		}finally{
			DBConn.close(perstat);
			DBConn.close(conn);
		}
		if(rows>0){
			return true;
		}else{
			return false;
		}
	}
	/**
	 * Methods
	 * @author dandelion
	 * @time 2019年3月12日下午4:59:00
	 * @方法名 addInfo
	 * @作用 添加学生详细信息
	 * @调用 AddStudentService.java
	 * @返回值类型 boolean，true表示插入成功，false表示插入失败
	 */
	public boolean addInfo(Info info){
		Connection conn = null;										//声明Connection对象
		PreparedStatement perstat =null;								//声明PreparedStatement对象
		//用i代替123456，当更换次序时，修改更方法，解耦
		int rows=0,i=1;
		try{
			conn=DBConn.getConnection();
			String sql="insert into info(id,name,sex,tel,qq,wechat,blog,github) values(?,?,?,?,?,?,?,?)";
			perstat=(PreparedStatement) conn.prepareStatement(sql);//执行SQL语句
			perstat.setLong(i,info.getId());
			i+=1;
			perstat.setString(i,info.getName());
			i+=1;
			perstat.setString(i,info.getSex());
			i+=1;
			perstat.setString(i,info.getTel());
			i+=1;
			perstat.setString(i,info.getQq());
			i+=1;
			perstat.setString(i,info.getWechat());
			i+=1;
			perstat.setString(i,info.getBlog());
			i+=1;
			perstat.setString(i,info.getGithub());
			rows=perstat.executeUpdate();//rows接收更新结果,rows大于0表示插入成功
		}catch(Exception e){
			System.out.println("【ManagerDaoImpl.java\\addInfo】插入详细信息数据时发生异常");
			e.printStackTrace();
		}finally{
			DBConn.close(perstat);
			DBConn.close(conn);
		}
		if(rows>0){
			return true;
		}else{
			return false;
		}
	}
	/**
	 * Methods
	 * @author dandelion
	 * @time 2019年3月12日下午4:59:20
	 * @方法名 addScore
	 * @作用 添加学生成绩信息
	 * @调用 AddStudentService.java
	 * @返回值类型 boolean，true表示插入成功，false表示插入失败
	 */
	public boolean addScore(Score score){
		Connection conn = null;										//声明Connection对象
		PreparedStatement perstat =null;								//声明PreparedStatement对象
		int rows=0;
		try{
			conn=DBConn.getConnection();
			String sql="insert into score(id,name,politics_score,english_subject,english_score,math_subject,math_score,major_subject,major_score,score_year) values(?,?,?,?,?,?,?,?,?,?)";
			perstat=(PreparedStatement) conn.prepareStatement(sql);//执行SQL语句
			perstat.setLong(1,score.getId());
			perstat.setString(2,score.getName());
			perstat.setString(3,score.getPolitics_score());
			perstat.setString(4,score.getEnglish_subject());
			perstat.setString(5,score.getEnglish_score());
			perstat.setString(6,score.getMath_subject());
			perstat.setString(7,score.getMajor_score());
			perstat.setString(8,score.getMajor_subject());
			perstat.setString(9,score.getMajor_score());
			perstat.setString(10,score.getScore_year());
			rows=perstat.executeUpdate();//rows接收更新结果,rows大于0表示插入成功
		}catch(Exception e){
			System.out.println("【ManagerDaoImpl.java\\addScore】插入成绩信息数据时发生异常");
			e.printStackTrace();
		}finally{
			DBConn.close(perstat);
			DBConn.close(conn);
		}
		if(rows>0){
			return true;
		}else{
			return false;
		}
	}
	/**
	 * Methods
	 * @author dandelion
	 * @time 2019年3月15日上午10:02:16
	 * @方法名 modifyStudent
	 * @作用 修改学生基本信息
	 * @调用 ModifyStudentService
	 * @返回值类型 boolean 返回true表示修改成功，返回false表示返回失败
	 */
	public boolean modifyStudent(Student student){
		Connection conn = null;										//声明Connection对象
		PreparedStatement perstat =null;								//声明PreparedStatement对象
		//用i代替123456，当更换次序时，修改更方法，解耦
		int rows=0,i=1;
		try{
			conn=DBConn.getConnection();
			String sql="update student set name=?,sch=?,college=?,major=?,class=?,register_sch=?,register_major=?,register_num=?,score_total=?,score_year=? where id=?";
			perstat=(PreparedStatement) conn.prepareStatement(sql);//执行SQL语句
			perstat.setString(i,student.getName());
			i+=1;
			perstat.setString(i,student.getSch());
			i+=1;
			perstat.setString(i,student.getCollege());
			i+=1;
			perstat.setString(i,student.getMajor());
			i+=1;
			perstat.setString(i,student.getClazz());
			i+=1;
			perstat.setString(i,student.getRegister_sch());
			i+=1;
			perstat.setString(i,student.getRegister_major());
			i+=1;
			perstat.setString(i,student.getRegister_num());
			i+=1;
			perstat.setInt(i,student.getScore_total());
			i+=1;
			perstat.setString(i,student.getScore_year());
			i+=1;
			perstat.setLong(i,student.getId());
			rows=perstat.executeUpdate();//rows接收更新结果,rows大于0表示插入成功
		}catch(Exception e){
			System.out.println("【ManagerDaoImpl.java\\modifyStudent】修改基本信息数据时发生异常");
			e.printStackTrace();
		}finally{
			DBConn.close(perstat);
			DBConn.close(conn);
		}
		if(rows>0){
			return true;
		}else{
			return false;
		}
	}
	/**
	 * Methods
	 * @author dandelion
	 * @time 2019年3月15日下午2:05:02
	 * @方法名 modifyInfo
	 * @作用 修改学生详细信息
	 * @调用 ModifyStudentService
	 * @返回值类型 boolean 返回true表示修改成功，返回false表示返回失败
	 */
	public boolean modifyInfo(Info info){
		Connection conn = null;										//声明Connection对象
		PreparedStatement perstat =null;								//声明PreparedStatement对象
		//用i代替123456，当更换次序时，修改更方法，解耦
		int rows=0,i=1;
		try{
			conn=DBConn.getConnection();
			String sql="update Info set name=?,sex=?,tel=?,qq=?,wechat=?,blog=?,github=? where id=?";
			perstat=(PreparedStatement) conn.prepareStatement(sql);//执行SQL语句
			perstat.setString(i,info.getName());
			i+=1;
			perstat.setString(i,info.getSex());
			i+=1;
			perstat.setString(i,info.getTel());
			i+=1;
			perstat.setString(i,info.getQq());
			i+=1;
			perstat.setString(i,info.getWechat());
			i+=1;
			perstat.setString(i,info.getBlog());
			i+=1;
			perstat.setString(i,info.getGithub());
			i+=1;
			perstat.setLong(i,info.getId());
			rows=perstat.executeUpdate();//rows接收更新结果,rows大于0表示插入成功
		}catch(Exception e){
			System.out.println("【ManagerDaoImpl.java\\modifyInfo】修改详细信息数据时发生异常");
			e.printStackTrace();
		}finally{
			DBConn.close(perstat);
			DBConn.close(conn);
		}
		if(rows>0){
			return true;
		}else{
			return false;
		}
	}
	/**
	 * Methods
	 * @author dandelion
	 * @time 2019年3月15日下午2:25:35
	 * @方法名 modifyScore
	 * @作用 修改学生成绩信息
	 * @调用 ModifyStudentService
	 * @返回值类型 boolean 返回true表示修改成功，返回false表示返回失败
	 */
	public boolean modifyScore(Score score){
		Connection conn = null;										//声明Connection对象
		PreparedStatement perstat =null;								//声明PreparedStatement对象
		//用i代替123456，当更换次序时，修改更方法，解耦
		int rows=0,i=1;
		try{
			conn=DBConn.getConnection();
			String sql="update score set name=?,politics_score=?,english_subject=?,english_score=?,math_subject=?,math_score=?,major_subject=?,major_score=?,score_year=? where id=?";
			perstat=(PreparedStatement) conn.prepareStatement(sql);//执行SQL语句
			perstat.setString(i,score.getName());
			i+=1;
			perstat.setString(i,score.getPolitics_score());
			i+=1;
			perstat.setString(i,score.getEnglish_subject());
			i+=1;
			perstat.setString(i,score.getEnglish_score());
			i+=1;
			perstat.setString(i,score.getMath_subject());
			i+=1;
			perstat.setString(i,score.getMajor_score());
			i+=1;
			perstat.setString(i,score.getMajor_subject());
			i+=1;
			perstat.setString(i,score.getMajor_score());
			i+=1;
			perstat.setString(i,score.getScore_year());
			i+=1;
			perstat.setLong(i,score.getId());
			rows=perstat.executeUpdate();//rows接收更新结果,rows大于0表示插入成功
		}catch(Exception e){
			System.out.println("【ManagerDaoImpl.java\\modifyScore】修改成绩信息数据时发生异常");
			e.printStackTrace();
		}finally{
			DBConn.close(perstat);
			DBConn.close(conn);
		}
		if(rows>0){
			return true;
		}else{
			return false;
		}
	}
	/**
	 * Methods
	 * @author dandelion
	 * @time 2019年3月17日下午4:28:43
	 * @方法名 updateNamebyId
	 * @作用 根据id更新三个表里的name数据
	 * @调用 修改学生基本信息的servlet：ModifyStudentService.java
	 * @返回值类型 
	 */
	public boolean updateNamebyId(Long id,String name){
		Connection conn = null;										//声明Connection对象
		PreparedStatement perstat =null;								//声明PreparedStatement对象
		//用i代替123456，当更换次序时，修改更方法，解耦
		int rows=0,i=1;
		try{
			conn=DBConn.getConnection();
			String sql="update student, info ,score "
					+ "set student.`name`=?,info.`name`=?,score.`name`=?"
					+ "where student.id=? and info.id=? and score.id=?";
			perstat=(PreparedStatement) conn.prepareStatement(sql);//执行SQL语句
			perstat.setString(i,name);
			i+=1;
			perstat.setString(i,name);
			i+=1;
			perstat.setString(i,name);
			i+=1;
			perstat.setLong(i,id);
			i+=1;
			perstat.setLong(i,id);
			i+=1;
			perstat.setLong(i,id);
			rows=perstat.executeUpdate();//rows接收更新结果,rows大于0表示插入成功
		}catch(Exception e){
			System.out.println("【ManagerDaoImpl.java\\updateNamebyId】根据id修改三表姓名时发生异常");
			e.printStackTrace();
		}finally{
			DBConn.close(perstat);
			DBConn.close(conn);
		}
		if(rows>0){
			return true;
		}else{
			return false;
		}
	}
}