package dao;

import java.sql.ResultSet;

import bean.Info;
import bean.Score;
import bean.Student;

/**
 * @author dandelion
 * @time 2019年3月16日下午8:47:11
 * @方法名 
 * @作用 
 * @调用 
 * @返回值类型 
 */
public interface ManagerDao {
	public String login(String id,String pwd);
	public ResultSet getManagerById(String id);
	public boolean addStudent(Student student);
	public boolean addInfo(Info info);
	public boolean addScore(Score score);
	public boolean modifyStudent(Student student);
	public boolean modifyInfo(Info info);
	public boolean modifyScore(Score score);
	public boolean updateNamebyId(Long id,String name);
}

