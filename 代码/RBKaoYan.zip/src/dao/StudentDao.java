package dao;

import java.sql.ResultSet;
import java.util.List;

import bean.Student;

/**
 * Types
 * @author dandelion
 * @time 2019年3月16日下午8:50:51
 * @接口名 StudentDao
 * @作用 学生操作的接口类
 * @调用 
 * @返回值类型 
 */
public interface StudentDao{
	public ResultSet getAllStudent();
	public ResultSet getStudentById(String id);
	/**
	 * Methods
	 * @author dandelion
	 * @time 2019年4月2日上午8:58:36
	 * @方法名 getStudentByYear
	 * @作用 根据考研年份获取学生信息
	 * @返回值类型 ResultSet
	*/
	public ResultSet getStudentByYear(String score_year);
	/**
	 * Methods
	 * @author dandelion
	 * @time 2019年4月3日下午4:39:23
	 * @方法名 getStudentByYearPage
	 * @作用 根据考研年份获取学生信息，但是数据分页，根据page和page的长度分成好几个页
	 * 		pageNow：希望显示第几页
	 * 		pageSize：每页显示多少条记录，暂时准备设定为15
	 * 		pageCount:一共有多少页
	 * @返回值类型 List<Student>
	*/
	public List<Student> getStudentByYearPage(String score_year,int pageNow,int pageSize);
	/**
	 * Methods
	 * @author dandelion
	 * @time 2019年4月3日下午4:52:20
	 * @方法名 getPageCountByYear
	 * @作用 根据考研年份获取一共有多少页数据
	 * @返回值类型 int
	*/
	public int getPageCountByYear(String score_year,int pageSize);
	public ResultSet getInfoById(String id);
	public ResultSet getScoreById(String id);
	/**
	 * Methods
	 * @author dandelion
	 * @time 2019年4月3日下午4:27:00
	 * @方法名 getStudentLengthByYear
	 * @作用 获取某个考研年份的学生的数据量
	*/
	public int getStudentCountByYear(String score_year);
}