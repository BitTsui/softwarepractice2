/*右键显示mytdcenter标签的id属性的值，并转到modifyStudentPage修改学生详细信息页面*/
/*右键显示mytdleft标签的id属性的值，并转到modifyInfoPage修改学生详细信息页面*/
/*右键显示mytdright标签的id属性的值，并转到modifyInfoPage修改学生详细信息页面*/
window.onload=function()
{
	/*var aObj=document.getElementsByTagName('tr');*/
	var center=document.getElementsByClassName("mytdcenter");
    for(var i=0;i<center.length;i++)
    {
    	center[i].oncontextmenu=function()
        {
            if(this.getAttribute('id'))
            {
            	var sid = this.getAttribute('id');
            	window.location.href="modifyStudentPage.jsp?id="+sid;
            }
            return false;
        }
    }
    var left=document.getElementsByClassName("mytdleft");
    for(var i=0;i<left.length;i++)
    {
    	left[i].oncontextmenu=function()
        {
            if(this.getAttribute('id'))
            {
            	var sid = this.getAttribute('id');
            	window.location.href="modifyInfoPage.jsp?id="+sid;
            }
            return false;
        }
    }
    var right=document.getElementsByClassName("mytdright");
    for(var i=0;i<right.length;i++)
    {
    	right[i].oncontextmenu=function()
        {
            if(this.getAttribute('id'))
            {
            	var sid = this.getAttribute('id');
            	window.location.href="modifyScorePage.jsp?id="+sid;
            }
            return false;
        }
    }
    document.oncontextmenu=function(){
        return false;
    }
}
/*HTML中取消鼠标右击事件，取消浏览器中body下的右击菜单*/
document.body.oncontextmenu = function (){
	return false
}
/*
鼠标移入事件over，
对应topBar.jsp
导航栏展出历年情况表【1是div的class属性多一个open
					2是div下a标签的aria-expanded属性变为true】
*/
function barOver(){
	var bardiv = document.getElementById("bardiv");
	bardiv.setAttribute("class","col-md-1 dropdown bargreen divhover open");
	document.getElementById("bardropdown").setAttribute("aria-expanded",true);
}
/*
鼠标移出事件over，
对应topBar.jsp
导航栏收回历年情况表【1是div的class属性少一个open
					2是div下a标签的aria-expanded属性变为false】
*/
function barOut(){
	var bardiv = document.getElementById("bardiv");
	bardiv.setAttribute("class","col-md-1 dropdown bargreen divhover");
	document.getElementById("bardropdown").setAttribute("aria-expanded",false);
}

/*
鼠标移入事件over，
管理员已登录的导航栏提示：
	mytdleft：【温馨提示：右键修改学生详细信息】
	mytdcenter：【温馨提示：右键修改学生基本信息】
	mytdright：【温馨提示：右键修改学生成绩信息】
*/
function myOver(){
	var name=document.getElementById("manager").innerHTML;
	if(name!="登录"){
		var mytd=document.getElementsByTagName("td");
		for(var i=0;i<mytd.length;i++)
	    {
			mytd[i].onmouseover=function()
	        {
	            if(this.getAttribute('class'))
	            {
	            	var clazz = this.getAttribute('class');
					if(clazz=="mytdleft"){
						document.getElementById("say").innerHTML="温馨提示：右键修改学生详细信息";
					}else if(clazz=="mytdcenter"){
						document.getElementById("say").innerHTML="温馨提示：右键修改学生基本信息";
					}else if(clazz=="mytdright"){
						document.getElementById("say").innerHTML="温馨提示：右键修改学生成绩信息";
					}
	            }
	            return false;
	        }
	    }
	}
}
//鼠标移出事件out
function myOut(){
	document.getElementById("say").innerHTML="";
}
//在添加学生基本信息的时候，输入学号，解锁提交按钮
function btnAbled(){
	//获取学号输入框
	var x=document.getElementById("idinput");
	//如果输入框内容不为空，解锁提交按钮，清楚提示信息
    if(x.value!=""){
    	document.getElementById("btn").removeAttribute('disabled');
    	document.getElementById("btnflag").innerHTML="";
    }
}
/*分页的前后页，设置为不可见*/
function myPreNext(pageNow,pageCount){
	if(pageNow==1){
		var myPre = document.getElementById("myPre");
		myPre.setAttribute("class","hide");
	}
	if(pageNow==pageCount){
		var myNext = document.getElementById("myNext");
		myNext.setAttribute("class","hide");
	}
}
/*将topBar上的登录，改成管理员名字*/
function setManagerName(name){
	document.getElementById("manager").innerHTML=name;
}
/* 获取管理员页面中输入的账号密码，
 * 然后携带数据，
 * 并跳转到loginCheck.jsp页面。
 * */
function loginCheck(){
	var id = document.getElementById("mid").value;
	var pwd = document.getElementById("mpwd").value;
	window.location.href="loginCheck.jsp?id="+id+"&pwd="+pwd;
}
/*跳转到mainPage.jsp页面*/
function mainPage(year){
	window.location.href="mainPage.jsp?score_year="+year;
}
/*跳转到loginPage.jsp页面*/
function loginPage(){
	window.location.href="loginPage.jsp";
}
/*跳转到managerPage.jsp页面*/
function managerPage(){
	window.location.href="managerPage.jsp";
}

/*跳转到addStudentPage.jsp页面*/
function addStudentPage(){
	window.location.href="addStudentPage.jsp";
}
/*跳转到addInfoPage.jsp页面*/
function addInfoPage(){
	window.location.href="addInfoPage.jsp";
}
/*跳转到addScorePage.jsp页面*/
function addScorePage(){
	window.location.href="addScorePage.jsp";
}

/*跳转到modifyStudentPage.jsp页面*/
function modifyStudentPage(){
	window.location.href="modifyStudentPage.jsp";
}      
/*跳转到modifyInfoPage.jsp页面*/
function modifyInfoPage(){
	window.location.href="modifyInfoPage.jsp";
}
/*跳转到modifyScorePage.jsp页面*/
function modifyScorePage(){
	window.location.href="modifyScorePage.jsp";
}